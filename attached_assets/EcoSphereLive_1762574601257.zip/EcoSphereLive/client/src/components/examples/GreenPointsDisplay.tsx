import GreenPointsDisplay from '../GreenPointsDisplay'

export default function GreenPointsDisplayExample() {
  return <GreenPointsDisplay points={2450} level={3} rank={127} />
}
