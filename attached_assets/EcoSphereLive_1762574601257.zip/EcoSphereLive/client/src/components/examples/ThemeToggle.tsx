import ThemeToggle from '../ThemeToggle'

export default function ThemeToggleExample() {
  return <ThemeToggle />
}
