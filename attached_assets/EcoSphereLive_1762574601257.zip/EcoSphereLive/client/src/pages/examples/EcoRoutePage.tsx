import EcoRoutePage from '../EcoRoutePage'

export default function EcoRoutePageExample() {
  return <EcoRoutePage />
}
