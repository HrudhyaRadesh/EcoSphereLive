import EcoTrackPage from '../EcoTrackPage'
import { Toaster } from "@/components/ui/toaster"

export default function EcoTrackPageExample() {
  return (
    <>
      <EcoTrackPage />
      <Toaster />
    </>
  )
}
