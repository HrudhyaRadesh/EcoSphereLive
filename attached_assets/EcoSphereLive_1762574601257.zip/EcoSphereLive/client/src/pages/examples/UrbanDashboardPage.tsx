import UrbanDashboardPage from '../UrbanDashboardPage'

export default function UrbanDashboardPageExample() {
  return <UrbanDashboardPage />
}
